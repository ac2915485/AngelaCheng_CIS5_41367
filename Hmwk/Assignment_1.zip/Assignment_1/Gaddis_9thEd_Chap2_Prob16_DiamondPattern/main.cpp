/* 
 * File:   main.cpp
 * Author: angela
 *
 * Created on January 5, 2021, 8:51 PM
 * Purpose: Gaddis_9thEd_Chap2_Prob16_DiamondPattern
 */

/*
 *This is a block comment
 */

//System Libraries
#include <iostream> //I/O Library
using namespace std;

//User Libraries


//Global Constants
//Math, Science, Universal, Conversions, High Dimensioned Arrays

//Function Prototypes

//Execution Begins Here
int main(int argc, char** argv) {
    //Initialize the Random Number Seed
    
    //Declare Variables
    string lnOne, //Line One
            lnTwo, //Line Two
            lnThree, //Line Three
            lnFour; //Line Four
    
    //Initialize Variables
    lnOne="   *   ";
    lnTwo="  ***  ";
    lnThree=" ***** ";
    lnFour="*******";
    
    //Map Inputs to Outputs -> Process
    
    //Display Inputs/Outputs
    cout<<lnOne<<endl;
    cout<<lnTwo<<endl;
    cout<<lnThree<<endl;
    cout<<lnFour<<endl;
    cout<<lnThree<<endl;
    cout<<lnTwo<<endl;
    cout<<lnOne<<endl;
    
    //Exit the Program - Cleanup
    return 0;
}

